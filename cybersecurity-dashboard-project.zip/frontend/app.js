document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("alerts-container");
    const statusIndicator = document.getElementById("status-indicator");

    // REZERVĂ PENTRU ANGAJATOR (GitHub Demo Mode)
    // Dacă angajatorul testează direct din GitHub sau fără XAMPP pornit, 
    // aplicația va rula impecabil folosind aceste date realiste.
    const gitHubDemoAlerts = [
        { source: "Kubernetes Audit", severity: "CRITICAL", message: "K8s Audit Fault: Containerul 'nginx-server' rulează în mod PRIVILEGIAT! S-a detectat bypass de izolare namespace.", detected_at: "Acum 2 min" },
        { source: "Linux Auth", severity: "HIGH", message: "Atac Brute Force detectat pe SSH. Tentativă utilizator 'root' de la IP neautorizat: 198.51.100.42", detected_at: "Acum 10 min" },
        { source: "JS Security", severity: "MEDIUM", message: "XSS Protection Activă: Scriptul malițios '<script>malicious_code()</script>' a fost neutralizat cu succes prin utilizarea textContent.", detected_at: "Acum 25 min" }
    ];

    function renderAlerts(alerts) {
        container.innerHTML = ""; 
        if (alerts.length === 0) {
            container.innerHTML = "<p class='no-alerts'>Nu s-au detectat vulnerabilități sau atacuri active.</p>";
            return;
        }

        alerts.forEach(alert => {
            const card = document.createElement("div");
            card.className = `alert-card ${alert.severity.toLowerCase()}`;
            
            const headerDiv = document.createElement("div");
            headerDiv.className = "card-header";
            
            // JS Security (Aparare XSS): Folosim TEXTCONTENT! În caz că un hacker introduce cod malițios 
            // în baza de date sau în loguri (ex: <script>), browserul îl va afișa ca text simplu, fără a-l executa.
            const title = document.createElement("h3");
            title.textContent = `[${alert.severity}] Sursă: ${alert.source}`;
            
            const timeSpan = document.createElement("span");
            timeSpan.className = "time-stamp";
            timeSpan.textContent = alert.detected_at || "Recent";
            
            headerDiv.appendChild(title);
            headerDiv.appendChild(timeSpan);
            
            const message = document.createElement("p");
            message.className = "alert-message";
            message.textContent = alert.message; 
            
            card.appendChild(headerDiv);
            card.appendChild(message);
            container.appendChild(card);
        });
    }

    // Încercăm interogarea backend-ului local PHP
    fetch("http://localhost/cybersecurity-dashboard/backend/get_alerts.php")
        .then(response => {
            if (!response.ok) throw new Error("Backend Deconectat");
            return response.json();
        })
        .then(data => {
            statusIndicator.textContent = "⚙️ LOCAL BACKEND CONECTAT (MySQL Live)";
            statusIndicator.className = "badge live";
            renderAlerts(data);
        })
        .catch(err => {
            // Logica salvatoare pentru GitHub
            console.warn("Backend local inactiv. Activare mod securizat GitHub DEMO.");
            statusIndicator.textContent = "🚀 GITHUB DEMO MODE ACTIVE";
            statusIndicator.className = "badge demo";
            renderAlerts(gitHubDemoAlerts);
        });
});
