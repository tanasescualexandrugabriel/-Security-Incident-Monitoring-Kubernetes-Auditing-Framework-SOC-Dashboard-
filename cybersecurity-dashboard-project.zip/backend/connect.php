<?php
// Setări CORS pentru a permite frontend-ului să acceseze API-ul de pe orice port local
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost";
$user = "root";
$pass = "";
$db   = "cyber_security";

// Conexiune MySQLi cu raportare dezactivată pentru a nu expune detalii sensibile în caz de eroare
mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli($host, $user, $pass, $db);

// Verificare defensivă: dacă pică baza de date, trimitem un status 500 curat
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Eroare internă de conexiune la baza de date locală."]);
    exit();
}
?>
