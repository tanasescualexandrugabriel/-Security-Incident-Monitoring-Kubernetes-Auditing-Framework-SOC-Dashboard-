<?php
// Includem conexiunea securizată
require_once "connect.php";

$sql = "SELECT id, source, severity, message, detected_at FROM security_alerts ORDER BY detected_at DESC";
$result = $conn->query($sql);

$alerts = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Securitate Backend: Criptare minimală a caracterelor speciale pentru transport sigur
        $alerts[] = [
            "id" => $row["id"],
            "source" => htmlspecialchars($row["source"]),
            "severity" => htmlspecialchars($row["severity"]),
            "message" => htmlspecialchars($row["message"]),
            "detected_at" => $row["detected_at"]
        ];
    }
}

echo json_encode($alerts);
$conn->close();
?>
