-- Crearea bazei de date pentru stocarea alertelor SOC
CREATE DATABASE IF NOT EXISTS cyber_security;
USE cyber_security;

CREATE TABLE IF NOT EXISTS security_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source VARCHAR(50) NOT NULL,       -- Sursa: 'Linux Auth', 'Kubernetes Audit', etc.
    severity VARCHAR(20) NOT NULL,     -- Nivel: 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
    message TEXT NOT NULL,             -- Detaliile atacului sau vulnerabilității
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Date inițiale de test pentru baza de date locală
INSERT INTO security_alerts (source, severity, message) VALUES 
('Linux Auth', 'HIGH', 'Failed SSH login attempt for user root from IP 192.168.1.50'),
('Kubernetes', 'CRITICAL', 'Pod running with privileged securityContext detected'),
('JS Security', 'MEDIUM', 'Outdated npm package with known XSS vulnerability found');
