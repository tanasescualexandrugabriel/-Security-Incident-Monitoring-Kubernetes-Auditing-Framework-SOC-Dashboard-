import yaml
import mysql.connector
import os

def audit_k8s_manifest():
    print("[*] Se inițiază scanarea manifestului Kubernetes...")
    file_path = os.path.join(os.path.dirname(__file__), '../k8s/deployment.yaml')
    
    try:
        with open(file_path, 'r') as file:
            data = yaml.safe_load(file)
    except Exception as e:
        print(f"[!] Eroare la citirea fișierului YAML: {e}")
        return

    try:
        db = mysql.connector.connect(host="localhost", user="root", password="", database="cyber_security")
        cursor = db.cursor()
    except mysql.connector.Error:
        cursor = None

    containers = data['spec']['template']['spec']['containers']
    for container in containers:
        sec_context = container.get('securityContext', {})
        
        # Regula 1: Verificare mod privilegiat
        if sec_context.get('privileged') == True:
            msg = f"K8s Audit Fault: Containerul '{container['name']}' rulează în mod PRIVILEGIAT!"
            print(f"[CRITICAL] {msg}")
            if cursor:
                cursor.execute("INSERT INTO security_alerts (source, severity, message) VALUES (%s, %s, %s)", ("Kubernetes", "CRITICAL", msg))
                
        # Regula 2: Verificare rulare ca root
        if sec_context.get('runAsUser') == 0:
            msg = f"K8s Audit Warning: Containerul '{container['name']}' rulează cu drepturi de ROOT (UID 0)."
            print(f"[WARNING] {msg}")
            if cursor:
                cursor.execute("INSERT INTO security_alerts (source, severity, message) VALUES (%s, %s, %s)", ("Kubernetes", "MEDIUM", msg))
                
    if cursor:
        db.commit()
        db.close()
        print("[+] Vulnerabilitățile K8s au fost salvate în baza de date.")

if __name__ == "__main__":
    audit_k8s_manifest()
