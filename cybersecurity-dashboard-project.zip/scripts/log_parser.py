import mysql.connector
import re
import sys

# Loguri Linux simulate (Atac de tip Brute Force pe SSH)
mock_linux_logs = [
    "Aug 01 12:01:20 server sshd[1234]: Failed password for invalid user admin from 198.51.100.42 port 49221 ssh2",
    "Aug 01 12:01:22 server sshd[1234]: Failed password for invalid user root from 198.51.100.42 port 49225 ssh2"
]

def analyze_logs():
    print("[*] Se inițiază analiza logurilor Linux...")
    try:
        db = mysql.connector.connect(host="localhost", user="root", password="", database="cyber_security")
        cursor = db.cursor()
    except mysql.connector.Error as err:
        print(f"[!] Eroare DB Locală: {err}. Scriptul rulează în mod analiză fără salvare.")
        cursor = None

    for log in mock_linux_logs:
        if "Failed password" in log:
            # Regex Security: Extragerea precisă a IP-ului atacatorului
            ip_match = re.search(r'from (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', log)
            user_match = re.search(r'for invalid user (\w+)', log)
            
            if ip_match and user_match:
                ip = ip_match.group(1)
                user = user_match.group(1)
                msg = f"Atac Brute Force detectat pe SSH. Tentativă utilizator '{user}' de la IP: {ip}"
                print(f"[ALERTĂ DETECTATĂ] {msg}")
                
                if cursor:
                    cursor.execute("INSERT INTO security_alerts (source, severity, message) VALUES (%s, %s, %s)", ("Linux Auth", "HIGH", msg))
    
    if cursor:
        db.commit()
        db.close()
        print("[+] Alerte salvate cu succes în MySQL.")

if __name__ == "__main__":
    analyze_logs()
